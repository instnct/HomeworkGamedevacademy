using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class MoveCar : MonoBehaviour
{
    [SerializeField]
    private float _speed = 5f;

    void Start()
    {
        var move = gameObject.GetComponent<Collider>();

        GameObject me = new GameObject("ge");
    }

    void Update()
    {
        var pos = gameObject.transform.position;
        var step = _speed * Time.deltaTime;

        if(Input.GetKey(KeyCode.W))
        {
            pos.z += step;
        }

        if (Input.GetKey(KeyCode.S))
        {
            pos.z -= step;
        }

        if (Input.GetKey(KeyCode.D))
        {
            pos.x += step;
        }

        if (Input.GetKey(KeyCode.A))
        {
            pos.x -= step;
        }

        transform.position = pos;
    }
}
