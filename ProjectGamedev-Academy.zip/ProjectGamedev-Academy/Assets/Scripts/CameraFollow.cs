using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    [SerializeField]
    private MoveCar _car;

    [SerializeField]
    private Vector3 _offset;

    private void Start()
    {
        _car = FindObjectOfType<MoveCar>();
    }

    private void LateUpdate()
    {
        transform.position = _car.transform.position + _offset;
    }
}
