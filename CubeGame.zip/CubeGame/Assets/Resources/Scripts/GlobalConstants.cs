public class GlobalConstants
{
    public const string PLAYER_TAG = "Player";
}